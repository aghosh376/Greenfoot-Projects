import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BallWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public BallWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1, false); 
        
        Ball bouncyBall = new Ball();
        addObject(bouncyBall, getWidth()/2, 300);
        
        for(int i = 0; i < 5; i++) {
            Brick kyle = new Brick();
            addObject(kyle, 90 + 105*i , 100);
        }
        
    }
}
